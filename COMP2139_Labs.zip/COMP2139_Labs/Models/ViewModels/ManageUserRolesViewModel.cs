﻿namespace COMP2139_Labs.Models.ViewModels
{
    public class ManageUserRolesViewModel
    {
        public string RoleID { get; set; }
        public string RoleName { get; set; }

        public bool Selected { get; set; }
    }
}
