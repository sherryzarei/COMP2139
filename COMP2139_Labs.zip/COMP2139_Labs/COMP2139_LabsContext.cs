﻿//https://github.com/sherryzarei/COMP2139/tree/main/COMP2139_Labs

internal class COMP2139_LabsContext
{
}